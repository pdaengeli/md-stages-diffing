







# Ansichten der Natur
vonAlexander von Humboldt.#  Erster Band.



# Ansichten der Natur,  mit wissenschaftlichen Erläuterungen. Von Alexander von Humboldt. Erster Band. Dritte verbesserte und vermehrte Ausgabe.



---


# Stuttgart und Tübingen. J. G. Cotta’scher Verlag. 1849.


Buchdrucherei der J. G. Cotta’schen Buchhandlung in Stuttgart.

#  Seinem theuren Bruder Wilhelm von Humboldt, in Rom, Berlin, im Mai 1807. der Verfasser.




# Vorrede zur ersten Ausgabe.
Schüchtern übergebe ich dem Publikum eine Reihe von Arbeiten, die im Angesicht großer Naturgegenstände, auf dem Ocean, in den Wäldern des Orinoco, in den Steppen von Venezuela, in der Einöde peruanischer und mexicanischer Gebirge, entstanden sind. Einzelne Fragmente wurden an Ort und Stelle niedergeschrieben, und nachmals nur in ein Ganzes zusammengeschmolzen. Ueberblick der Natur im großen, Beweis von dem Zusammenwirken der Kräfte, Erneuerung des Genusses, welchen die unmittelbare Ansicht der Tropenländer dem fühlenden Menschen gewährt: sind die Zwecke, nach denen ich strebe. Jeder Aufsatz sollte ein in sich geschlossenes Ganzes ausmachen, in allen sollte eine und dieselbe Tendenz sich gleichmäßig aussprechen. Diese ästhetische Behandlung naturhistorischer Gegenstände hat, trotz der herrlichen Kraft und der Biegsamkeit unserer vaterländischen Sprache, große Schwierigkeiten der Composition. Reichthum der Natur veranlaßt Anhäufung einzelner Bilder, und Anhäufung stört die Ruhe und den Totaleindruck des Gemäldes. Das Gefühl und die Phantasie ansprechend, artet der Styl leicht in eine dichterische Prosa aus. Diese Ideen bedürfen hier keiner Entwickelung, da die nachstehenden Blätter mannigfaltige Beispiele solcher Verirrungen, solchen Mangels an Haltung darbieten.

Mögen meine Ansichten der Natur, trotz dieser Fehler, welche ich selbst leichter rügen als verbessern kann, dem Leser doch einen Theil des Genusses gewähren, welchen ein empfänglicher Sinn in der unmittelbaren Anschauung findet. Da dieser Genuß mit der Einsicht in den inneren Zusammenhang der Naturkräfte vermehrt wird, so sind jedem Aufsatze wissenschaftliche Erläuterungen und Zusätze beigefügt.

Ueberall habe ich auf den ewigen Einfluß hingewiesen, welchen die physische Natur auf die moralische Stimmung der Menschheit und auf ihre Schicksale ausübt. Bedrängten Gemüthern sind diese Blätter vorzugsweise gewidmet. „Wer sich herausgerettet aus der stürmischen Lebenswelle“, folgt mir gern in das Dickicht der Wälder, durch die unabsehbare Steppe und auf den hohen Rücken der Andeskette. Zu ihm spricht der weltrichtende Chor:


Auf den Bergen ist Freiheit! Der Hauch der Grüfte
Steigt nicht hinauf in die reinen Lüfte;
Die Welt ist vollkommen überall,
Wo der Mensch nicht hinkommt mit seiner Qual.




---




# Vorrede zur zweiten und dritten Ausgabe.
Die zwiefache Richtung dieser Schrift (ein sorgsames Bestreben, durch lebendige Darstellungen den Naturgenuß zu erhöhen, zugleich aber nach dem dermaligen Stande der Wissenschaft die Einsicht in das harmonische Zusammenwirken der Kräfte zu vermehren) ist in der Vorrede zur ersten Ausgabe, fast vor einem halben Jahrhundert, bezeichnet worden. Es sind damals schon die mannigfaltigen Hindernisse angegeben, welche der ästhetischen Behandlung großer Naturscenen entgegenstehn. Die Verbindung eines litterarischen und eines rein scientisischen Zweckes, der Wunsch, gleichzeitig die Phantasie zu beschäftigen und durch Vermehrung des Wissens das Leben mit Ideen zu bereichern: machen die Anordnung der einzelnen Theile und das, was als Einheit der Composition gefordert wird, schwer zu erreichen. Trotz dieser ungünstigen Verhältnisse hat das Publikum der unvollkommenen Ausführung meines Unternehmens dauernd ein nachsichtsvolles Wohlwollen geschenkt.

Die zweite Ausgabe der Ansichten der Natur habe ich in Paris im Jahr 1826 besorgt. Zwei Aufsätze: ein „Versuch über den Bau und die Wirkungsart der Vulkane in den verschiedenen Erdstrichen“, und die „Lebenskraft oder der rhodische Genius“, wurden damals zuerst beigefügt. Schiller, in jugendlicher Erinnerung an seine medicinischen Studien, unterhielt sich während meines langen Aufenthalts in Jena gern mit mir über physiologische Gegenstände. Meine Arbeit über die Stimmung der gereizten Muskel- und Nervenfaser durch Berührung mit chemisch verschiedenen Stoffen gab oft unsern Gesprächen eine ernstere Richtung. Es entstand in jener Zeit der kleine Aufsatz von der Lebenskraft. Die Vorliebe, welche Schiller für den „rhodischen Genius“ hatte, den er in seine Zeitschrift der Horen aufnahm, gab mir den Muth ihn wieder abdrucken zu lassen. Mein Bruder berührt in einem Briefe, welcher erst vor kurzem gedruckt worden ist (Wilhelm von Humboldt’s Briefe an eine Freundin Th. II. S. 39), mit Zartheit denselben Gegenstand, setzt aber treffend hinzu: „Die Entwickelung einer physiologischen Idee ist der Zweck des ganzen Aufsatzes. Man liebte in der Zeit, in welcher derselbe geschrieben ist, mehr, als man jetzt thun würde, solche halbdichterische Einkleidungen ernsthafter Wahrheiten.“

Es ist mir noch im achtzigsten Jahre die Freude geworden, eine dritte Ausgabe meiner Schrift zu vollenden und dieselbe nach den Bedürfnissen der Zeit ganz umzuschmelzen. Fast alle wissenschaftliche Erläuterungen sind ergänzt oder durch neue, inhaltreichere ersetzt worden. Ich habe gehofft den Trieb zum Studium der Natur dadurch zu beleben, daß in dem kleinsten Raume die mannigfaltigsten Resultate gründlicher Beobachtung zusammengedrängt, die Wichtigkeit genauer numerischer Angaben und ihrer sinnigen Vergleichung unter einander erkannt, und dem dogmatischen Halbwissen wie der vornehmen Zweifelsucht gesteuert werde, welche in den sogenannten höheren Kreisen des geselligen Lebens einen langen Besitz haben.

Die Expedition, die ich in Gemeinschaft mit Ehrenberg und Gustav Rose auf Befehl des Kaisers von Rußland im Jahre 1829 in das nördliche Asien (in den Ural, den Altai und an die Ufer des caspischen Meeres) gemacht, fällt zwischen die Epochen der 2ten und 3ten Ausgabe meines Buches. Sie hat wesentlich zur Erweiterung meiner Ansichten beigetragen in allem, was die Gestaltung der Bodenfläche, die Richtung der Gebirgsketten, den Zusammenhang der Steppen und Wüsten, die geographische Verbreitung der Pflanzen nach gemessenen Temperatur-Einflüssen betrifft. Die Unkenntniß, in welcher man so lange über die zwei großen schneebedeckten Gebirgszüge zwischen dem Altai und Himalaya, über den Thian-schan und den Kuen-lün, gewesen ist, hat bei der ungerechten Vernachlässigung chinesischer Quellen die Geographie von Inner-Asien verdunkelt und Phantasien als Resultate der Beobachtung in vielgelesenen Schriften verbreitet. Seit wenigen Monaten sind fast unerwartet der hypsometrischen Vergleichung der culminirenden Gipfel beider Continente wichtige und berichtigende Erweiterungen zugekommen, deren Kunde zuerst in der nachfolgenden Schrift (Bd. I. S. 75—76 und 116—117) hat gegeben werden können. Die von früheren Irrthümern befreiten Höhenbestimmungen zweier Berge in der östlichen Andeskette von Bolivia, des Sorata und Illimani, haben dem Chimborazo seinen alten Rang unter den Schneebergen des Neuen Continents mit Gewißheit noch nicht ganz wieder ertheilt, während im Himalaya die neue trigonometrische Messung des Kinchinjinga (26438 Pariser Fuß) diesem Gipfel den nächsten Platz nach dem, nun ebenfalls trigonometrisch genauer gemessenen Dhawalagiri einräumt.

Um die numerische Gleichförmigkeit mit den zwei vorigen Ausgaben der Ansichten der Natur zu bewahren, sind die Temperatur-Angaben in diesem Werke, wenn nicht das Gegentheil bestimmt ausgesprochen ist, in Graden des 80theiligen Réaumur’schen Thermometers ausgedrückt. Das Fußmaaß ist das altfranzösische, in welchem die Toise 6 Pariser Fuß zählt. Die Meilen sind geographische, deren 15 auf einen Aequatorial-Grad gehen. Die Längen sind vom ersten Meridian der Pariser Sternwarte gerechnet.

Berlin, im März 1849.




# Ueber die Steppen und Wüsten.


Am Fuße des hohen Granitrückens, welcher im Jugendalter unseres Planeten, bei Bildung des antillischen Meerbusens, dem Einbruch der Wasser getrotzt hat, beginnt eine weite, unabsehbare Ebene. Wenn man die Bergthäler von Caracas und den inselreichen See Tacarigua¹, in dem die nahen Pisang-Stämme sich spiegeln; wenn man die Fluren, welche mit dem zarten und lichten Grün des tahitischen Zuckerschilfes prangen, oder den ernsten Schatten der Cacao-Gebüsche zurückläßt: so ruht der Blick im Süden auf Steppen, die scheinbar ansteigend, in schwindender Ferne, den Horizont begrenzen.

Aus der üppigen Fülle des organischen Lebens tritt der Wanderer betroffen an den öden Rand einer baumlosen, pflanzenarmen Wüste. Kein Hügel, keine Klippe erhebt sich inselförmig in dem unermeßlichen Raume. Nur hier und dort liegen gebrochene Flözschichten von zweihundert Quadratmeilen Oberfläche, bemerkbar höher als die angrenzenden Theile. Bänke² nennen die Eingebornen diese Erscheinung, gleichsam ahndungsvoll durch die Sprache den alten Zustand der Dinge bezeichnend, da jene Erhöhungen Untiefen, die Steppen selbst aber der Boden eines großen Mittelmeeres waren.

Noch gegenwärtig ruft oft nächtliche Täuschung diese Bilder der Vorzeit zurück. Wenn im raschen Aufsteigen und Niedersinken die leitenden Gestirne den Saum der Ebene erleuchten; oder wenn sie zitternd ihr Bild verdoppeln in der untern Schicht der wogenden Dünste: glaubt man den küstenlosen Ocean³ vor sich zu sehen. Wie dieser, erfüllt die Steppe das Gemüth mit dem Gefühl der Unendlichkeit, und durch dies Gefühl, wie den sinnlichen Eindrücken des Raumes sich entwindend, mit geistigen Anregungen höherer Ordnung. Aber freundlich zugleich ist der Anblick des klaren Meeresspiegels, in welchem die leichtbewegliche, sanft aufschäumende Welle sich kräuselt; todt und starr liegt die Steppe hingestreckt, wie die nackte Felsrinde⁴ eines verödeten Planeten.

In allen Zonen bietet die Natur das Phänomen dieser großen Ebenen dar; in jeder haben sie einen eigenthümlichen Charakter, eine Physiognomie, welche durch die Verschiedenheit ihres Bodens, durch ihr Klima und durch ihre Höhe über der Oberfläche des Meeres bestimmt wird.

Im nördlichen Europa kann man die Heideländer, welche, von einem einzigen, alles verdrängenden Pflanzenzuge bedeckt, von der Spitze von Jütland sich bis an den Ausfluß der Schelde erstrecken, als wahre Steppen betrachten: aber Steppen von geringer Ausdehnung und hochhüglichter Oberfläche, wenn man sie mit den Llanos und Pampas von Südamerika, oder gar mit den Grasfluren am Missouri⁵ und Kupferflusse vergleicht, in denen der zottige Bison und der kleine Moschusstier umherschwärmen.

Einen größeren und ernsteren Anblick gewähren die Ebenen im Innern von Afrika. Gleich der weiten Fläche des Stillen Oceans hat man sie erst in neueren Zeiten zu durchforschen versucht; sie sind Theile eines Sandmeeres, welches gegen Osten fruchtbare Erdstriche von einander trennt oder inselförmig einschließt, wie die Wüste am Basaltgebirge Harudsch⁶, wo in der dattelreichen Oasis von Siwah die Trümmer des Ammon-Tempels den ehrwürdigen Sitz früher Menschenbildung bezeichnen. Kein Thau, kein Regen benetzt diese öden Flächen und entwickelt im glühenden Schooß der Erde den Keim des Pflanzenlebens. Denn heiße Luftsäulen steigen überall aufwärts, lösen die Dünste und verscheuchen das vorübereilende Gewölk.

Wo die Wüste sich dem atlantischen Ocean nähert, wie zwischen Wadi Nun und dem Weißen Vorgebirge, da strömt die feuchte Meeresluft hin, die Leere zu füllen, welche durch jene senkrechten Winde erregt wird. Selbst wenn der Schiffer durch ein Meer, das wiesenartig mit Seetang bedeckt ist, nach der Mündung des Gambia steuert; ahndet er, wo ihn plötzlich der tropische Ostwind verläßt⁷, die Nähe des weitverbreiteten wärmestrahlenden Sandes.

Heerden von Gazellen und schnellfüßige Strauße durchirren den unermeßlichen Raum. Rechnet man ab die im Sandmeere neuentdeckten Gruppen quellenreicher Inseln, an deren grünen Ufern die nomadischen Tibbos und Tuaryks⁸ schwärmen, so ist der übrige Theil der afrikanischen Wüste als dem Menschen unbewohnbar zu betrachten. Auch wagen die angrenzenden gebildeten Völker sie nur periodisch zu betreten. Auf Wegen, die der Handelsverkehr seit Jahrtausenden unwandelbar bestimmt hat, geht der lange Zug von Tafilet bis Tombuktu, oder von Murzuk bis Bornu: kühne Unternehmungen, deren Möglichkeit auf der Existenz des Kameels beruht, des Schiffs der Wüste⁹, wie es die alten Sagen der Ostwelt nennen.

Diese afrikanischen Ebenen füllen einen Raum aus, welcher den des nahen Mittelmeeres fast dreimal übertrifst. Sie liegen zum Theil unter den Wendekreisen selbst, zum Theil denselben nahe; und diese Lage begründet ihren individuellen Naturcharakter. Dagegen ist in der östlichen Hälfte des alten Continents dasselbe geognostische Phänomen mehr der gemäßigten Zone eigenthümlich.

Auf dem Bergrücken von Mittel-Asien zwischen dem Goldberge oder Altai und dem Kuen-lün¹⁰, von der chinesischen Mauer an bis jenseits des Himmelsgebirges und gegen den Aral-See hin, in einer Länge von mehreren tausend Meilen, breiten sich, wenn auch nicht die höchsten, doch die größten Steppen der Welt aus. Einen Theil derselben, die Kalmücken- und Kirghisen-Steppen zwischen dem Don, der Wolga, dem caspischen Meere und dem chinesischen Dsaisang-See, also in einer Erstreckung von fast 700 geographischen Meilen, habe ich selbst zu sehen Gelegenheit gehabt, volle dreißig Jahre nach meiner südamerikanischen Reise. Die Vegetation der asiatischen, bisweilen hügeligen und durch Fichtenwälder unterbrochenen Steppen ist gruppenweise viel mannigfaltiger als die der Llanos und Pampas von Caracas und Buenos Aires. Der schönere Theil der Ebenen, von asiatischen Hirtenvölkern bewohnt, ist mit niedrigen Sträuchern üppig weißblühender Rosaceen, mit Kaiserkronen (Fritillarien), Tulpen und Cypripedien geschmückt. Wie die heiße Zone sich im ganzen dadurch auszeichnet, daß alles Vegetative baumartig zu werden strebt, so charakterisirt einige Steppen der asiatischen gemäßigten Zone die wundersame Höhe, zu der sich blühende Kräuter erheben: Saussureen und andere Synanthereen; Schotengewächse, besonders ein Heer von Astragalus-Arten. Wenn man in den niedrigen tatarischen Fuhrwerken sich durch weglose Theile dieser Krautsteppen bewegt, kann man nur aufrecht stehend sich orientiren, und sieht die waldartig dichtgedrängten Pflanzen sich vor den Rädern niederbeugen. Einige dieser asiatischen Steppen sind Grasebenen; andere mit saftigen, immergrünen, gegliederten Kali-Pflanzen bedeckt; viele fernleuchtend von flechtenartig aufsprießendem Salze, das ungleich, wie frischgefallener Schnee, den lettigen Boden verhüllt.

Diese mongolischen und tatarischen Steppen, durch mannigfaltige Gebirgszüge unterbrochen, scheiden die uralte, langgebildete Menschheit in Tübet und Hindostan von den rohen, nord-asiatischen Völkern. Auch ist ihr Dasein von mannigfaltigem Einfluß auf die wechselnden Schicksale des Menschengeschlechts gewesen. Sie haben die Bevölkerung gegen Süden zusammengedrängt; mehr als der Himalaya, als das Schneegebirge von Sirinagur und Gorka den Verkehr der Nationen gestört, und im Norden Asiens unwandelbare Grenzen gesetzt der Verbreitung milderer Sitten und des schaffenden Kunstsinns.

Aber nicht als hindernde Vormauer allein darf die Geschichte die Ebene von Inner-Asien betrachten. Unheil und Verwüstung hat sie mehrmals über den Erdkreis gebracht. Hirtenvölker dieser Steppe: die Mongolen, Geten, Alanen und Usün, haben die Welt erschüttert. Wenn in dem Lauf der Jahrhunderte frühe Geistescultur, gleich dem erquickenden Sonnenlicht, von Osten nach Westen gewandert ist; so haben späterhin, in derselben Richtung, Barbarei und sittliche Roheit Europa nebelartig zu überziehen gedroht. Ein brauner Hirtenstamm¹¹ (tukiuischer, d. i. türkischer Abkunft), die Hiongnu, bewohnte in ledernen Gezelten die hohe Steppe von Gobi. Der chinesischen Macht lange furchtbar, ward ein Theil des Stammes südlich nach Inner-Asien zurückgedrängt. Dieser Stoß der Völker pflanzte sich unaufhaltsam bis in das alte Finnenland am Ural fort. Von dort aus brachen Hunnen, Avaren, Chasaren und mannigfaltige Gemische asiatischer Menschenracen hervor. Hunnische Kriegsheere erschienen erst an der Wolga, dann in Pannonien, dann an der Marne und an den Ufern des Po: die schön bepflanzten Fluren verheerend, wo seit Antenors Zeiten die bildende Menschheit Denkmal auf Denkmal gehäuft. So wehte aus den mongolischen Wüsten ein verpesteter Windeshauch, der auf cisalpinischem Boden die zarte, langgepflegte Blüthe der Kunst erstickte.

Von den Salzsteppen Asiens, von den europäischen Heideländern, die im Sommer mit honigreichen, röthlichen Blumen prangen, und von den pflanzenleeren Wüsten Afrika’s kehren wir zu den Ebenen von Südamerika zurück, deren Gemälde ich bereits angefangen habe mit rohen Zügen zu entwerfen.

Das Interesse, welches ein solches Gemälde dem Beobachter gewähren kann, ist aber ein reines Naturinteresse. Keine Oase erinnert hier an frühe Bewohner, kein behauener Stein¹², kein verwilderter Fruchtbaum an den Fleiß untergegangener Geschlechter. Wie den Schicksalen der Menschheit fremd, allein an die Gegenwart fesselnd: liegt dieser Erdwinkel da, ein wilder Schauplatz des freien Thier-und Pflanzenlebens.


Von der Küstenkette von Caracas erstreckt sich die Steppe bis zu den Wäldern der Guyana; von den Schneebergen von Merida, an deren Abhange der Natrum-See Urao ein Gegenstand des religiösen Aberglaubens der Eingebornen ist, bis zu dem großen Delta, welches der Orinoco an seiner Mündung bildet. Südwestlich zieht sie sich gleich einem Meeresarme¹³ jenseits der Ufer des Meta und des Vichada bis zu den unbesuchten Quellen des Guaviare, und bis zu dem einsamen Gebirgsstock hin, welchen spanische Kriegsvölker, im Spiel ihrer regsamen Phantasie, den Paramo de la Suma Paz, gleichsam den schönen Sitz des ewigen Friedens, nannten.

Diese Steppe nimmt einen Raum von 16000 Quadratmeilen ein. Aus geographischer Unkunde hat man sie oft in gleicher Breite als ununterbrochen bis an die Magellanische Meerenge fortlaufend geschildert: nicht eingedenk der waldigen Ebene des Amazonenflusses, welche gegen Norden und Süden von den Grassteppen des Apure und des La Plata-Stromes begrenzt wird. Die Andeskette von Cochabamba und die brasilianische Berggruppe senden, zwischen der Provinz Chiquitos und der Landenge von Villabella, einzelne Bergjoche sich entgegen¹⁴. Eine schmale Ebene vereinigt die Hyläa des Amazonenflusses mit den Pampas von Buenos Aires. Letztere übertreffen die Llanos von Venezuela dreimal an Flächeninhalt. Ja ihre Ausdehnung ist so wundervoll groß, daß sie auf der nördlichen Seite durch Palmengebüsche begrenzt und auf der südlichen fast mit ewigem Eise bedeckt sind. Der casuar-ähnliche Tuyu (Struthio Rhea) ist diesen Pampas eigenthümlich: wie die Colonien verwilderter Hunde¹⁵, welche gesellig in unterirdischen Höhlen wohnen, aber oft blutgierig den Menschen anfallen, für dessen Vertheidigung ihre Stammväter kämpften.

Gleich dem größten Theile der Wüste Zahara¹⁶ liegen die Llanos, oder die nördlichste Ebene von Südamerika, in dem heißen Erdgürtel. Dennoch erscheinen sie in jeder Hälfte des Jahres unter einer verschiedenen Gestalt: bald verödet, wie das libysche Sandmeer; bald als eine Grasflur, wie so viele Steppen von Mittel-Asien¹⁷.

Es ist ein belohnendes, wenn gleich schwieriges Geschäft der allgemeinen Länderkunde, die Naturbeschaffenheit entlegener Erdstriche mit einander zu vergleichen und die Resultate dieser Vergleichung in wenigen Zügen darzustellen. Mannigfaltige, zum Theil noch wenig entwickelte Ursachen vermindern die Dürre und Wärme des neuen Welttheils.¹⁸

Schmalheit der vielfach eingeschnittenen Feste in der nördlichen Tropengegend, wo eine flüssige Grundfläche der Atmosphäre einen minder warmen aufsteigenden Luftstrom darbietet; weite Ausdehnung gegen beide beeiste Pole hin; ein freier Ocean, über den die tropischen kühleren Seewinde wegblasen; Flachheit der östlichen Küsten; Ströme kalten Meereswassers aus der antarctischen Region, welche, anfänglich von Südwest nach Nordost gerichtet, unter dem Parallelkreis von 35° südlicher Breite an die Küste von Chili anschlagen und an den Küsten von Peru bis zum Cap Pariña nördlich vordringen, sich dann plötzlich gegen Westen wendend; die Zahl quellenreicher Gebirgsketten, deren schneebedeckte Gipfel weit über alle Wolkenschichten emporstreben und an ihrem Abhange herabsteigende Luftströmungen veranlassen; die Fülle der Flüsse von ungeheurer Breite, welche nach vielen Windungen stets die entfernteste Küste suchen; sandlose und darum minder erhitzbare Steppen; undurchdringliche Wälder, welche, den Boden vor den Sonnenstrahlen schützend oder durch ihre Blattflächen wärmestrahlend, die flußreiche Ebene am Aequator ausfüllen, und im Innern des Landes, wo Gebirge und Ocean am entlegensten sind, ungeheure Massen theils eingesogenen, theils selbsterzeugten Wassers aushauchen: — alle diese Verhältnisse gewähren dem flachen Theile von Amerika ein Klima, das mit dem afrikanischen durch Feuchtigkeit und Kühlung wunderbar contrastirt. In ihnen allein liegt der Grund jenes üppigen, saftstrotzenden Pflanzenwuchses, jener Frondosität, welche der eigenthümliche Charakter des Neuen Continents ist.

Wird daher eine Seite unsers Planeten luftfeuchter als die andere genannt, so ist die Betrachtung des gegenwärtigen Zustandes der Dinge hinlänglich, das Problem dieser Ungleichheit zu lösen. Der Physiker braucht die Erklärung solcher Naturerscheinungen nicht in das Gewand geologischer Mythen zu hüllen. Es bedarf der Annahme nicht, als habe sich auf dem uralten Erdkörper in der östlichen und westlichen Hemisphäre ungleichzeitig geschlichtet der verderbliche Streit der Elemente; oder als sei aus der chaotischen Wasserbedeckung Amerika später als die übrigen Welttheile hervorgetreten, ein sumpfreiches, von Crocodilen und Schlangen bewohntes Eiland.¹⁹

Allerdings hat Südamerika, nach der Gestalt seines Umrisses und der Richtung seiner Küsten, eine auffallende Aehnlichkeit mit der südwestlichen Halbinsel des alten Continents. Aber innere Structur des Bodens und relative Lage zu den angrenzenden Ländermassen bringen in Afrika jene wunderbare Dürre hervor, welche in unermeßlichen Räumen der Entwickelung des organischen Lebens entgegensteht. Vier Fünftheile von Südamerika liegen jenseits des Aequators: also in einer Hemisphäre, welche wegen der größeren Wassermenge und wegen mannigfaltiger anderer Ursachen kühler und feuchter als unsre nördliche Halbkugel ist.²⁰ Dieser letzteren gehört dagegen der beträchtlichere Theil von Afrika zu.

Die südamerikanische Steppe, die Llanos, haben, von Osten gegen Westen gemessen, eine dreimal geringere Ausdehnung als die afrikanischen Wüsten. Jene empfangen den tropischen Seewind; diese, unter Einem Breiten-Zirkel mit Arabien und dem südlichen Persien gelegen, werden von Luftschichten berührt, die über heiße, wärmestrahlende Continente hinwehen. Auch hat bereits der ehrwürdige, langverkannte Vater der Geschichte, Herodot, im ächten Sinn einer großen Naturansicht, alle Wüsten in Nord-Afrika, in Yemen, Kerman und Mekran (der Gedrosia der Griechen), ja bis Multan in Vorder-Indien hin, als ein einziges zusammenhangendes Sandmeer²¹ geschildert.

Zu der Wirkung heißer Landwinde gesellt sich in Afrika, so weit wir es kennen, noch der Mangel an großen Flüssen, an Wasserdampf aushauchenden, kälteerregenden Wäldern und hohen Gebirgen. Mit ewigem Eise bedeckt ist bloß der westliche Theil des Atlas²², dessen schmales Bergjoch, seitwärts gesehen, den alten Küstenfahrern wie eine einzeln stehende luftige Himmelsstütze erschien. Oestlich läuft das Gebirge bis gegen Dakul hin, wo, jetzt in Schutt versunken, das meergebietende Carthago lag. Als langgedehnte Küstenkette, als gätulische Vormauer, hält es die kühlen Nordwinde und mit ihnen die aus dem Mittelmeere aufsteigenden Dämpfe zurück.

Ueber die untere Schneegrenze erhaben dachte man sich einst das Mondgebirge, Djebel al-Komr²³, von welchem man fabelte, daß es einen Bergparallel zwischen dem afrikanischen Quito, der hohen Ebene von Habesch, und den Quellen des Senegal bilde. Selbst die Cordillere von Lupata, die sich an der östlichen Küste von Mozambique und Monomotapa, wie die Andeskette an der westlichen Küste von Peru, hinzieht, ist in dem goldreichen Machinga und Mocanga mit ewigem Eise bedeckt. Aber diese wasserreichen Gebirge liegen weit entfernt von der ungeheuren Wüste, welche sich von dem südlichen Abfall des Atlas bis an den östlich fließenden Niger erstreckt.

Vielleicht wären alle diese aufgezählten Ursachen der Dürre und Wärme nicht hinlänglich, so beträchtliche Theile der afrikanischen Ebenen in ein furchtbares Sandmeer zu verwandeln, hätte nicht irgend eine Naturrevolution, z. B. der einbrechende Ocean, einst diese flache Gegend ihrer Pflanzendecke und der nährenden Dammerde beraubt. Wann diese Erscheinung sich zutrug, welche Kraft den Einbruch bestimmte, ist tief in das Dunkel der Vorzeit gehüllt. Vielleicht war sie Folge des großen Wirbels²⁴, welcher die wärmeren mexicanischen Gewässer über die Bank von Neufundland an den alten Continent treibt, und durch welchen westindische Cocosnüsse und andere Tropenfrüchte nach Irland und Norwegen gelangen. Wenigstens ist ein Arm dieses Meeresstroms noch gegenwärtig, von den Azoren an, gegen Südosten gerichtet und schlägt, dem Schiffer Unheil bringend, an das westliche Dünenufer von Afrika. Auch zeigen alle Meeresküsten (ich erinnere an die peruanischen zwischen Amotape und Coquimbo), wie Jahrhunderte, ja vielleicht Jahrtausende, vergehen, bevor in heißen regenlosen Erdstrichen, wo weder Lecideen noch andere Flechten²⁵ keimen, der bewegliche Sand den Kräuterwurzeln einen sicheren Standort zu gewähren vermag.

Diese Betrachtungen genügen, um zu erklären, warum, trotz der äußern Aehnlichkeit der Länderform, Afrika und Südamerika doch die abweichendsten klimatischen Verhältnisse, den verschiedensten Vegetations-Charakter darbieten. Ist aber auch die südamerikanische Steppe mit einer dünnen Rinde fruchtbarer Erde bedeckt, wird sie auch periodisch durch Regengüsse getränkt und dann mit üppig aufschießendem Grase geschmückt; so hat sie doch die angrenzenden Völkerstämme nicht reizen können die schönen Bergthäler von Caracas, das Meeresufer und die Flußwelt des Orinoco zu verlassen, um sich in dieser baum- und quellenleeren Einöde zu verlieren. Daher ward die Steppe, bei der Ankunft europäischer und afrikanischer Ansiedler, fast menschenleer gefunden.

Allerdings sind die Llanos zur Viehzucht geeignet; aber die Pflege milchgebender Thiere²⁶ war den ursprünglichen Einwohnern des Neuen Continents fast unbekannt. Kaum wußte einer der amerikanischen Völkerstämme die Vortheile zu benutzen, welche die Natur auch in dieser Hinsicht ihnen dargeboten hatte. Die amerikanische Menschenrace (eine und dieselbe von 65° nördlicher bis 55° südlicher Breite, die Eskimos etwa abgerechnet) ging vom Jagdleben nicht durch die Stufe des Hirtenlebens zum Ackerbau über. Zwei Arten einheimischer Rinder weiden in den Grasfluren von West-Canada, in Quivira, wie um die colossalen Trümmer der Azteken-Burg, welche (ein amerikanisches Palmyra) sich verlassen in der Einöde am Gila-Flusse erhebt. Ein langhörniges Mouflon, ähnlich dem sogenannten Stammvater des Schafes, schwärmt auf den dürren und nackten Kalkfelsen von Californien umher. Der südlichen Halbinsel sind die Vicuñas, Huanacos, Alpacas und Lamas eigenthümlich. Aber von diesen nutzbaren Thieren haben nur die ersten zwei Jahrtausende lang ihre natürliche Freiheit bewahrt. Genuß von Milch und Käse ist, wie der Besitz und die Cultur mehlreicher Grasarten²⁷, ein charakteristisches Unterscheidungszeichen der Nationen des alten Welttheils.

Sind daher von diesen einige Stämme durch das nördliche Asien auf die Westküste von Amerika übergegangen, und haben sie, kälteliebend²⁸, den hohen Andesrücken gegen Süden verfolgt; so muß diese Wanderung auf Wegen geschehen sein, auf welchen weder Heerden noch Cerealien den neuen Ankömmling begleiten konnten. Sollte vielleicht, als das lang erschütterte Reich der Hiongnu zerfiel, das Fortwälzen dieses mächtigen Stammes auch im Nordosten von China und Korea Völkerzüge veranlaßt haben, bei denen gebildete Asiaten in den Neuen Continent übergingen? Wären diese Ankömmlinge Bewohner von Steppen gewesen, in denen Ackerbau nicht betrieben wird; so würde diese gewagte, durch Sprachvergleichung bisher wenig begünstigte Hypothese wenigstens den auffallenden Mangel der eigentlichen Cerealien in Amerika erklären. Vielleicht landete an den Küsten von Neu-Californien, durch Stürme verschlagen, eine von jenen asiatischen Priester-Colonien, welche mystische Träumereien zu fernen Seefahrten veranlaßten und von denen die Bevölkerungsgeschichte von Japan²⁹ zur Zeit der Thsinschi-huang-ti ein denkwürdiges Beispiel liefert.

Blieb demnach das Hirtenleben, diese wohlthätige Mittelstufe, welche nomadische Jägerhorden an den grasreichen Boden fesselt und gleichsam zum Ackerbau vorbereitet, den Urvölkern Amerika’s unbekannt; so liegt in dieser Unbekanntschaft selbst der Grund von der Menschenleere der südamerikanischen Steppen. Um so freier haben sich in ihr die Naturkräfte in mannigfaltigen Thiergestalten entwickelt: frei, und nur durch sich selbst beschränkt, wie das Pflanzenleben in den Wäldern am Orinoco, wo der Hymenäe und dem riesenstämmigen Lorbeer nie die verheerende Hand des Menschen, sondern nur der üppige Andrang schlingender Gewächse droht. Agutis, kleine buntgefleckte Hirsche, gepanzerte Armadille, welche rattenartig den Hasen in seiner unterirdischen Höhle aufschrecken; Heerden von trägen Chiguiren, schön gestreifte Viverren, welche die Luft verpesten; der große ungemähnte Löwe; buntgefleckte Jaguars (meist Tiger genannt), die den jungen selbsterlegten Stier auf einen Hügel zu schleppen vermögen: — diese und viele andere Thiergestalten³⁰ durchirren die baumlose Ebene.

Fast nur ihnen bewohnbar, hätte sie keine der nomadischen Völkerhorden, die ohnedies (nach asiatisch-indischer Art) die vegetabilische Nahrung vorziehen, fesseln können, stände nicht hier und da die Fächerpalme, Mauritia, zerstreut umher. Weit berühmt sind die Vorzüge dieses wohlthätigen Lebensbaumes. Er allein ernährt am Ausflusse des Orinoco, nördlich von der Sierra de Imataca, die unbezwungene Nation der Guaraunen.³¹ Als sie zahlreicher und zusammengedrängt waren, erhoben sie nicht bloß ihre Hütten auf abgehauenen Palmenpfosten, die ein horizontales Tafelwerk als Fußboden trugen; sie spannten auch (so geht die Sage) Hangematten, aus den Blattstielen der Mauritia gewebt, künstlich von Stamm zu Stamm, um in der Regenzeit, wenn das Delta überschwemmt ist, nach Art der Affen auf den Bäumen zu leben. Diese schwebenden Hütten wurden theilweise mit Letten bedeckt. Auf der feuchten Unterlage schürten die Weiber zu häuslichem Bedürfniß Feuer an. Wer bei Nacht auf dem Flusse vorüberfuhr, sah die Flammen reihenweise auflodern, hoch in der Luft, von dem Boden getrennt. Die Guaraunen verdanken noch jetzt die Erhaltung ihrer physischen und vielleicht selbst ihrer moralischen Unabhängigkeit dem lockeren, halbflüssigen Moorboden, über den sie leichtfüßig fortlaufen, und ihrem Aufenthalt auf den Bäumen: einer hohen Freistatt, zu der religiöse Begeisterung wohl nie einen amerikanischen Styliten³² leiten wird.

Aber nicht bloß sichere Wohnung, auch mannigfaltige Speise gewährt die Mauritia. Ehe auf der männlichen Palme die zarte Blüthenscheide ausbricht, und nur in dieser Periode der Pflanzen-Metamorphose, enthält das Mark des Stammes ein sagoartiges Mehl, welches, wie das Mehl der Jatropha-Wurzel, in dünnen brodtähnlichen Scheiben gedörrt wird. Der gegohrne Saft des Baums ist der süße, berauschende Palmwein der Guaraunen. Die engschuppigen Früchte, welche röthlichen Tannenzapfen gleichen, geben, wie Pisang und fast alle Früchte der Tropenwelt, eine verschiedenartige Nahrung: je nachdem man sie nach völliger Entwicklung ihres Zuckerstoffes, oder früher, im mehlreichen Zustande, genießt. So finden wir auf der untersten Stufe menschlicher Geistesbildung (gleich dem Insect, das auf einzelne Blüthentheile beschränkt ist) die Existenz eines ganzen Völkerstammes an fast einen einzigen Baum gefesselt.

Seit der Entdeckung des Neuen Continents sind die Ebenen (Llanos) dem Menschen bewohnbar geworden. Um den Verkehr zwischen der Küste und der Guyana (dem Orinoco-Lande) zu erleichtern, sind hier und da Städte³³ an den Steppenflüssen erbaut. Ueberall hat Viehzucht in dem unermeßlichen Raume begonnen. Tagereisen von einander entfernt liegen einzelne, mit Rindsfellen gedeckte, aus Schilf und Riemen geflochtene Hütten. Zahllose Schaaren verwilderter Stiere, Pferde und Maulesel (man schätzte sie zur friedlichen Zeit meiner Reise noch auf anderthalb Millionen Köpfe) schwärmen in der Steppe umher. Die ungeheure Vermehrung dieser Thiere der alten Welt ist um so bewundernswürdiger, je mannigfaltiger die Gefahren sind, mit denen sie in diesen Erdstrichen zu kämpfen haben.

Wenn unter dem senkrechten Strahl der niebewölkten Sonne die verkohlte Grasdecke in Staub zerfallen ist, klafft der erhärtete Boden auf, als wäre er von mächtigen Erdstößen erschüttert. Berühren ihn dann entgegengesetzte Luftströme, deren Streit sich in kreisender Bewegung ausgleicht, so gewährt die Ebene einen seltsamen Anblick. Als trichterförmige Wolken³⁴, die mit ihren Spitzen an der Erde hingleiten, steigt der Sand dampfartig durch die luftdünne, electrisch geladene Mitte des Wirbels empor: gleich den rauschenden Wasserhosen, die der erfahrne Schiffer fürchtet. Ein trübes, fast strohfarbiges Halblicht wirft die nun scheinbar niedrigere Himmelsdecke auf die verödete Flur. Der Horizont tritt plötzlich näher. Er verengt die Steppe, wie das Gemüth des Wanderers. Die heiße, staubige Erde, welche im nebelartig verschleierten Dunstkreise schwebt, vermehrt die erstickende Luftwärme.³⁵ Statt Kühlung führt der Ostwind neue Gluth herbei, wenn er über den langerhitzten Boden hinweht.

Auch verschwinden allmählich die Lachen, welche die gelb gebleichte Fächerpalme vor der Verdunstung schützte. Wie im eisigen Norden die Thiere durch Kälte erstarren: so schlummert hier, unbeweglich, das Crocodil und die Boa-Schlange, tief vergraben in trockenem Letten. Ueberall verkündigt Dürre den Tod; und doch überall verfolgt den Dürstenden, im Spiele des gebogenen Lichtstrahls, das Trugbild³⁶ des wellenschlagenden Wasserspiegels. Ein schmaler Luftstreifen trennt das ferne Palmengebüsch vom Boden. Es schwebt durch Kiemung gehoben bei der Berührung ungleich erwärmter und also ungleich dichter Luftschichten. In finstere Staubwolken gehüllt, von Hunger und brennendem Durste geängstigt, schweifen Pferde und Rinder umher: diese dumpf aufbrüllend; jene mit langgestrecktem Halse gegen den Wind anschnaubend, um durch die Feuchtigkeit des Luftstroms die Nähe einer nicht ganz verdampften Lache zu errathen.

Bedächtiger und verschlagener, sucht das Maulthier auf andere Weise seinen Durst zu lindern. Eine kugelförmige und dabei vielrippige Pflanze, der Melonen-Cactus³⁷, verschließt unter seiner stachligen Hülle ein wasserreiches Mark. Mit dem Vorderfuße schlägt das Maulthier die Stacheln seitwärts, und wagt es dann erst die Lippen behutsam zu nähern und den kühlen Distelsaft zu trinken. Aber das Schöpfen aus dieser lebendigen vegetabilischen Quelle ist nicht immer gefahrlos; oft sieht man Thiere, welche von Cactus-Stacheln am Hufe gelähmt sind.

Folgt auf die brennende Hitze des Tages die Kühlung der, hier immer gleich langen Nacht, so können Rinder und Pferde selbst dann nicht sich der Ruhe erfreuen. Ungeheure Fledermäuse saugen ihnen, während des Schlafes, vampyrartig das Blut aus; oder hängen sich an dem Rücken fest, wo sie eiternde Wunden erregen, in welche Mosquitos, Hippoboscen und eine Schaar stechender Insecten sich ansiedeln. So führen die Thiere ein schmerzenvolles Leben, wenn vor der Gluth der Sonne das Wasser auf dem Erdboden verschwindet.

Tritt endlich nach langer Dürre die wohlthätige Regenzeit ein, so verändert³⁸ sich plötzlich die Scene in der Steppe. Das tiefe Blau des bis dahin nie bewölkten Himmels wird lichter. Kaum erkennt man bei Nacht den schwarzen Raum im Sternbild des südlichen Kreuzes. Der sanfte phosphorartige Schimmer der Magellanischen Wolken verlischt. Selbst die scheitelrechten Gestirne des Adlers und des Schlangenträgers leuchten mit zitterndem, minder planetarischem Lichte. Wie ein entlegenes Gebirge, erscheint einzelnes Gewölk im Süden, senkrecht aufsteigend am Horizonte. Nebelartig breiten allmählich die vermehrten Dünste sich über den Zenith aus. Den belebenden Regen verkündigt der ferne Donner.

Kaum ist die Oberfläche der Erde benetzt, so überzieht sich die duftende Steppe mit Kyllingien, mit vielrispigem Paspalum und mannigfaltigen Gräsern. Vom Lichte gereizt, entfalten krautartige Mimosen ihre gesenkt schlummernden Blätter, und begrüßen die aufgehende Sonne, wie der Frühgesang der Vögel und die sich öffnenden Blüthen der Wasserpflanzen. Pferde und Rinder weiden nun in frohem Genusse des Lebens. Das hoch aufschießende Gras birgt den schöngefleckten Jaguar. Im sicheren Versteck auflauernd und die Weite des einigen Sprunges vorsichtig messend, erhascht er die vorüberziehenden Thiere, katzenartig wie der asiatische Tiger.

Bisweilen sieht man (so erzählen die Eingeborenen) an den Ufern der Sümpfe den befeuchteten Letten sich langsam und schollenweise erheben.³⁹ Mit heftigem Getöse, wie beim Ausbruche kleiner Schlammvulkane, wird die aufgewühlte Erde hoch in die Luft geschleudert. Wer des Anblicks kundig ist, flieht die Erscheinung; denn eine riesenhafte Wasserschlange oder ein gepanzertes Crocodil steigen aus der Gruft hervor, durch den ersten Regenguß aus dem Scheintode erweckt.

Schwellen nun allmählich die Flüsse, welche die Ebene südlich begrenzen: der Arauca, der Apure und der Payara; so zwingt die Natur dieselben Thiere, welche in der ersten Jahreshälfte auf dem wasserleeren, staubigen Boden vor Durst verschmachteten, als Amphibien zu leben. Ein Theil der Steppe erscheint nun wie ein unermeßliches Binnenwasser.⁴⁰ Die Mutterpferde ziehen sich mit den Füllen auf die höheren Bänke zurück, welche inselförmig über dem Seespiegel hervorragen. Mit jedem Tage verengt sich der trockene Raum. Aus Mangel an Weide schwimmen die zusammengedrängten Thiere stundenlang umher, und nähren sich kärglich von der blühenden Grasrispe, die sich über dem braungefärbten gährenden Wasser erhebt. Viele Füllen ertrinken; viele werden von den Crocodilen erhascht, mit dem zackigen Schwanze zerschmettert, und verschlungen. Nicht selten bemerkt man Pferde und Rinder, welche, dem Rachen dieser blutgierigen, riesenhaften Eidechsen entschlüpft, die Spur des spitzigen Zahnes am Schenkel tragen.

Ein solcher Anblick erinnert unwillkührlich den ernsten Beobachter an die Biegsamkeit, mit welcher die alles aneignende Natur gewisse Thiere und Pflanzen begabt hat. Wie die mehlreichen Früchte der Ceres, so sind Stier und Roß dem Menschen über den ganzen Erdkreis gefolgt: vom Ganges bis an den Plata-Strom, von der afrikanischen Meeresküste bis zur Gebirgsebene des Antisana, welche höher als der Kegelberg von Teneriffa liegt.⁴¹ Hier schützt die nordische Birke, dort die Dattelpalme den ermüdeten Stier vor dem Strahl der Mittagssonne. Dieselbe Thiergattung, welche im östlichen Europa mit Bären und Wölfen kämpft, wird unter einem anderen Himmelsstriche von den Angriffen der Tiger und der Crocodile bedroht!

Aber nicht die Crocodile und der Jaguar allein stellen den südamerikanischen Pferden nach; auch unter den Fischen haben sie einen gefährlichen Feind. Die Sumpfwasser von Bera und Rastro⁴² sind mit zahllosen electrischen Aalen gefüllt, deren schleimiger, gelbgefleckter Körper aus jedem Theile die erschütternde Kraft nach Willkühr aussendet. Diese Gymnoten haben 5 bis 6 Fuß Länge. Sie sind mächtig genug die größten Thiere zu tödten, wenn sie ihre nervenreichen Organe auf einmal in günstiger Richtung entladen. Die Steppenstraße von Uritucu mußte einst verändert werden, weil sich die Gymnoten in solcher Menge in einem Flüßchen angehäuft hatten, daß jährlich vor Betäubung viele Pferde in der Fuhrt ertranken. Auch fliehen alle anderen Fische die Nähe dieser furchtbaren Aale. Selbst den Angelnden am hohen Ufer schrecken sie, wenn die feuchte Schnur ihm die Erschütterung aus der Ferne zuleitet. So bricht hier electrisches Feuer aus dem Schooße der Gewässer aus.

Ein malerisches Schauspiel gewährt der Fang der Gymnoten. Man jagt Maulthiere und Pferde in einen Sumpf, welchen die Indianer eng umzingeln, bis der ungewohnte Lärmen die muthigen Fische zum Angriff reizt. Schlangenartig sieht man sie auf dem Wasser schwimmen und sich, verschlagen, unter den Bauch der Pferde drängen. Von diesen erliegen viele der Stärke unsichtbarer Schläge. Mit gesträubter Mähne, schnaubend, wilde Angst im funkelnden Auge, fliehen andere das tobende Ungewitter. Aber die Indianer, mit langen Bambusstäben bewaffnet, treiben sie in die Mitte der Lache zurück.

Allmählich läßt die Wuth des ungleichen Kampfes nach. Wie entladene Wolken zerstreuen sich die ermüdeten Fische. Sie bedürfen einer langen Ruhe und einer reichlichen Nahrung, um zu sammeln, was sie an galvanischer Kraft verschwendet haben. Schwächer und schwächer erschüttern nun allmählich ihre Schläge. Vom Geräusch der stampfenden Pferde erschreckt, nahen sie sich furchtsam dem Ufer, wo sie durch Harpune verwundet und mit dürrem, nicht leitendem Holze auf die Steppe gezogen werden.

Dies ist der wunderbare Kampf der Pferde und Fische. Was unsichtbar die lebendige Waffe dieser Wasserbewohner ist; was, durch die Berührung feuchter und ungleichartiger Theile⁴³ erweckt, in allen Organen der Thiere und Pflanzen umtreibt; was die weite Himmelsdecke donnernd entflammt, was Eisen an Eisen bindet und den stillen wiederkehrenden Gang der leitenden Nadel lenkt: alles, wie die Farbe des getheilten Lichtstrahls, fließt aus Einer Quelle; alles schmilzt in eine ewige, allverbreitete Kraft zusammen.

Ich könnte hier den gewagten Versuch eines Naturgemäldes der Steppe schließen. Aber wie auf dem Ocean die Phantasie sich gern mit den Bildern ferner Küsten beschäftigt; so werfen auch wir, ehe die große Ebene uns entschwindet, vorher einen flüchtigen Blick auf die Erdstriche, welche die Steppe begrenzen.


Afrika’s nördliche Wüste scheidet die beiden Menschenarten, welche ursprünglich demselben Welttheil angehören und deren unausgeglichener Zwist so alt als die Mythe von Osiris und Typhon⁴⁴ scheint. Nördlich vom Atlas wohnen schlicht- und langhaarige Völkerstämme von gelber Farbe und kaukasischer Gesichtsbildung. Dagegen leben südlich vom Senegal, gegen Sudan hin, Negerhorden, die auf mannigfaltigen Stufen der Civilisation gefunden werden. In Mittel-Asien ist, durch die mongolische Steppe, sibirische Barbarei von der uralten Menschenbildung auf der Halbinsel von Hindostan getrennt.

Auch die südamerikanischen Ebenen begrenzen das Gebiet europäischer Halbcultur.⁴⁵ Nördlich, zwischen der Gebirgskette von Venezuela und dem antillischen Meere, liegen gewerbsame Städte, reinliche Dörfer und sorgsam bebaute Fluren an einander gedrängt. Selbst Kunstsinn, wissenschaftliche Bildung und die edle Liebe zu Bürgerfreiheit sind längst darinnen erwacht.

Gegen Süden umgiebt die Steppe eine schaudervolle Wildniß. Tausendjährige Wälder, ein undurchdringliches Dickicht erfüllen den feuchten Erdstrich zwischen dem Orinoco und dem Amazonenstrome. Mächtige, bleifarbige⁴⁶ Granitmassen verengen das Bett der schäumenden Flüsse. Berge und Wälder hallen wieder von dem Donner der stürzenden Wasser, von dem Gebrüll des tigerartigen Jaguar, von dem dumpfen, regenverkündenden⁴⁷ Geheul der bärtigen Affen.

Wo der seichte Strom eine Sandbank übrig läßt, da liegen mit offenem Rachen, unbeweglich wie Felsstücke hingestreckt, oft bedeckt mit Vögeln⁴⁸, die ungeschlachten Körper der Crocodile. Den Schwanz um einen Baumast befestigt, zusammengerollt, lauert am Ufer, ihrer Beute gewiß, die schachbrett-fleckige Boa-Schlange. Schnell entrollt und vorgestreckt, ergreift sie in der Furth den jungen Stier oder das schwächere Wildpret, und zwängt den Raub, in Geifer gehüllt, mühsam durch den schwellenden⁴⁹ Hals.

In dieser großen und wilden Natur leben mannigfaltige Geschlechter der Menschen. Durch wunderbare Verschiedenheit der Sprachen gesondert, sind einige nomadisch, dem Ackerbau fremd, Ameisen Gummi und Erde genießend⁵⁰, ein Auswurf der Menschheit (wie die Otomaken und Jaruren); andere angesiedelt, von selbsterzielten Früchten genährt, verständig und sanfterer Sitten (wie die Maquiritarer und Macos). Große Räume zwischen dem Cassiquiare und dem Atabapo sind nur vom Tapir und von geselligen Affen, nicht von Menschen, bewohnt. In Felsen gegrabene Bilder⁵¹ beweisen, daß auch diese Einöde einst der Sitz höherer Cultur war. Sie zeugen für die wechselnden Schicksale der Völker; wie es auch die ungleich entwickelten, biegsamen Sprachen thun, welche zu den ältesten und unvergänglichsten historischen Denkmälern der Menschheit gehören.

Wenn aber in der Steppe Tiger und Crocodile mit Pferden und Rindern kämpfen; so sehen wir an ihrem waldigen Ufer, in den Wildnissen der Guyana, ewig den Menschen gegen den Menschen gerüstet. Mit unnatürlicher Begier trinken hier einzelne Völkerstämme das ausgesogene Blut ihrer Feinde; andere würgen, scheinbar waffenlos und doch zum Morde vorbereitet⁵², mit vergiftetem Daum-Nagel. Die schwächeren Horden, wenn sie das sandige Ufer betreten, vertilgen sorgsam mit den Händen die Spur ihrer schüchternen Tritte.

So bereitet der Mensch auf der untersten Stufe thierischer Roheit, so im Scheinglanze seiner höheren Bildung sich stets ein mühevolles Leben. So verfolgt den Wanderer über den weiten Erdkreis, über Meer und Land, wie den Geschichtsforscher durch alle Jahrhunderte, das einförmige, trostlose Bild des entzweiten Geschlechts.

Darum versenkt, wer im ungeschlichteten Zwist der Völker nach geistiger Ruhe strebt, gern den Blick in das stille Leben der Pflanzen und in der heiligen Naturkraft inneres Wirken; oder, hingegeben dem angestammten Triebe, der seit Jahrtausenden der Menschen Brust durchglüht, blickt er ahndungsvoll aufwärts zu den hohen Gestirnen, welche in ungestörtem Einklang die alte, ewige Bahn vollenden.




---






---






---






---






---






---






---








---






---






---






---






---






---






---











